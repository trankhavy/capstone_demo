import os
import numpy as np
import cv2
from glob import glob
import tensorflow as tf
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, CSVLogger, TensorBoard

from src.data import load_data, tf_dataset
from src.unet import build_model
from src.config import DATA_DIR, BATCH_SIZE, RESULT_DIR, LOG_DIR, IMG_SIZE


IMG_PATH = os.path.join(DATA_DIR,'images')
MASK_PATH = os.path.join(DATA_DIR,'masks')
EPOCHS = 5
LR = 1e-4


if __name__ == "__main__":
    (train_x,train_y), (valid_x,valid_y), (test_x,test_y) = load_data(IMG_PATH,MASK_PATH)

    train_dataset = tf_dataset(train_x,train_y,batch=BATCH_SIZE)
    valid_dataset = tf_dataset(valid_x,valid_y,batch=BATCH_SIZE)

    np.save("train_x",train_x)
    np.save("train_y",train_y)
    np.save("valid_x",valid_x)
    np.save("valid_y",valid_y)
    np.save("test_x",test_x)
    np.save("test_y",test_y)

    model = build_model()
    opt = tf.keras.optimizers.Adam(LR)
    metrics = tf.keras.metrics.CategoricalAccuracy(name="categorical_accuracy", dtype=None)

    model.compile(loss="categorical_crossentropy", optimizer=opt, metrics=[metrics])

    callbacks = [
        ModelCheckpoint(os.path.join(RESULT_DIR,"model.h5")),
        ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=4),
        CSVLogger(os.path.join(LOG_DIR,"logger.csv")),
        TensorBoard(),
        EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=False)
    ]

    train_steps = len(train_x) // BATCH_SIZE
    valid_steps = len(valid_x) // BATCH_SIZE

    if len(train_x) % BATCH_SIZE != 0:
        train_steps += 1
    if len(valid_x) % BATCH_SIZE != 0:
        valid_steps += 1

    print(model.summary())
    model.fit(train_dataset,
              validation_data=valid_dataset,
              epochs=EPOCHS,
              steps_per_epoch=train_steps,
              validation_steps=valid_steps,
              callbacks=callbacks)